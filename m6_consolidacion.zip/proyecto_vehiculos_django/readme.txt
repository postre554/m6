PROYECTO DE VEHICULOS DJANGO M6 


ACCESO


    super user
    nombre: admin
    email: admin@admin.com
    clave: metric12345


    super user
    nombre: romo
    email: romo@eductec.no
    clave: metric12345



    common user
    nombre: vlado
    email: romo@eductec.no
    clave: metric12345



## RECORDATORIO

    se encuentran en : requirements.txt

pasos para instalar DEPENDENCIAS

    1-instalar entorno virtual:
        py.exe -m venv venv
    2- activar entorno virtual
        .\venv\scripts\activate
    3- restaurar DEPENDENCIAS
        pip install -r .\requirements.txt






